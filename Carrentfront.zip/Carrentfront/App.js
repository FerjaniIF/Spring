import React from 'react';
import './App.css';
import './components/CarsList.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import CarsList from './components/CarsList';
import { Route, Routes, useLocation } from 'react-router-dom';
import Login from './components/Login';
import Signup from './Signup';
import Header from "./header/Header";
import HomePage from './HomePage';
import CarDetail from './components/CarDetail';
import './components/CarDetail.css';

function App() {
  const location = useLocation();

  return ( 
    <div className="App">
      {location.pathname === "/" && <Header />}
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/Login' element={<Login />} />
        <Route path='/Signup' element={<Signup />} />
        <Route path='/List-cars' element={<CarsList />} />
        <Route path='/Car-detail' element={<CarDetail />} />
      </Routes>
    </div>
  );  
}

export default App;
