import "./Signup.css";
import PropTypes from "prop-types";
import { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const Signup = ({ className = "" }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    country: "",
    city: "",
    password: "",
    repassword: ""
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const navigate = useNavigate();

  const handleSubmit = async(e) =>{
    e.preventDefault();
    console.log(formData);
    try {
      const response = await fetch("http://localhost:8001/api/auth/signup" , {
        method : "POST",
        headers : { "Content-Type": "application/json"},
        body : JSON.stringify(formData)
      });

      const data = await response.json();
      console.log("User created : ", data);
      navigate("/List-cars")
    } catch (error) {
      console.log("Error creating a client" , error.message);
    }
  }


  return (
    <Form className={`signup ${className}`} onSubmit={handleSubmit}>
      <div className="background" />
      <section className="close-button">
        <div className="account-icon-parent">
          <div className="account-icon">
            <div className="close-icon">
              <div className="account-info">
                <img
                  className="accounticon"
                  loading="lazy"
                  alt=""
                  src="/accounticon1.svg"
                />
              </div>
            </div>
          </div>
          <h3 className="create-your-account">Create your Account</h3>
        </div>
      </section>
      <Form.Group controlId="formSign">
        <Form.Control
          className="name-input"
          placeholder="Name"
          type="text"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="formSign">
        <Form.Control
          className="email-input"
          placeholder="Email Address"
          type="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="formSign">
        <div className="phone-input">
          <div className="phonenumber">
            <div className="phonenumber-child" />
            <div className="phone-input-prefix">
              <div className="country-code">
                <b className="country-code-placeholder">+216</b>
                <div className="arrows-upper-arrow-wrapper">
                  <img
                    className="arrows-upper-arrow"
                    alt=""
                    src="/arrows--upper-arrow.svg"
                  />
                </div>
              </div>
            </div>
            <div className="phone-icon">
              <img
                className="phone-input-icon"
                alt=""
                src="/phone-input-icon.svg"
              />
            </div>
            <Form.Control
              className="phone-label"
              placeholder="Phone number"
              type="text"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
            />
          </div>
        </div>
      </Form.Group>
      <Form.Group controlId="formSign">
        <div className="location-input">
          <div className="location-fields">
            <Form.Control
              className="country"
              placeholder="Country"
              type="text"
              name="country"
              value={formData.country}
              onChange={handleInputChange}
            />
            <Form.Control
              className="city"
              placeholder="City"
              type="text"
              name="city"
              value={formData.city}
              onChange={handleInputChange}
            />
          </div>
        </div>
      </Form.Group>
      <Form.Group controlId="formSign">
        <div className="password-input">
          <div className="password">
            <div className="password-child" />
            <Form.Control
              className="password1"
              placeholder="Password"
              type="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
            />
            <div className="eye-icon">
              <img
                className="outlinestatuseye-closed-icon"
                alt=""
                src="/outlinestatuseyeclosed1.svg"
              />
            </div>
          </div>
        </div>
      </Form.Group>
      <Form.Group controlId="formSign">
        <div className="password-input1">
          <div className="re-enterpassword">
            <div className="re-enterpassword-child" />
            <Form.Control
              className="reenter-password"
              placeholder="Reenter Password"
              type="password"
              name="repassword"
              value={formData.repassword}
              onChange={handleInputChange}
            />
            <div className="outlinestatuseye-closed-wrapper">
              <img
                className="outlinestatuseye-closed-icon1"
                alt=""
                src="/outlinestatuseyeclosed-1.svg"
              />
            </div>
          </div>
        </div>
      </Form.Group>
      <footer className="terms-checkbox">
        <div className="agreement">
          <Button type="submit" className="signup1">
            Sign up
          </Button>
        </div>
      </footer>
    </Form>
  );
};

Signup.propTypes = {
  className: PropTypes.string,
};

export default Signup;
