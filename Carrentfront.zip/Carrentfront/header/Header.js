import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';
import { Link } from 'react-router-dom';
import "../components/FrameComponent4.css";

const Header = () => {
  return (
    <Navbar className="navigation">
      <Container className="home">
        <Navbar.Brand as={Link} to="/" className="mycarnow">MyCarNow</Navbar.Brand>
        <Nav className="navigation-inner frame-parent30">
          <Nav.Link as={Link} to="/Login" className="nav-items nav-items-child sign-up1">Log In</Nav.Link>
          <Nav.Link as={Link} to="/Signup" className="nav-items nav-items-child sign-up1">Sign Up</Nav.Link>
        </Nav>
      </Container>
    </Navbar>
  );
}

export default Header;
