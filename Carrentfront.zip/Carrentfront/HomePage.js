import FrameComponent4 from "./components/FrameComponent4";
import FrameComponent3 from "./components/FrameComponent3";
import FrameComponent1 from "./components/FrameComponent11";
import FrameComponent from "./components/FrameComponent5";
import Footer from "./components/Footer";
import PropTypes from "prop-types";
import "./HomePage.css";
import "./globalHome.css";

const HomePage = ({ className = "" }) => {
  return (
    <div className={`home-page ${className}`}> 
      <img
        className="unsplashfmbwfdivrps-icon"
        alt=""
        src="/unsplashfmbwfdivrps@2x.png"
      />
      <FrameComponent4 />
      <section className="home-page-inner">
        <div className="frame-group">
          <FrameComponent3 />
          <FrameComponent1 />
          <div className="pricing-wrapper">
            <h1 className="pricing">Pricing</h1>
          </div>
          <FrameComponent />
        </div>
      </section>
      <Footer />
    </div>
  );
};

HomePage.propTypes = {
  className: PropTypes.string,
};

export default HomePage;
