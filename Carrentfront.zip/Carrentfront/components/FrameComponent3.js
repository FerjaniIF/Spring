import "./FrameComponent3.css";
import PropTypes from 'prop-types';


const FrameComponent3 = ({ className = "" }) => {
  return (
    <div className={`showcase-container-wrapper ${className}`}>
      <div className="showcase-container">
        <div className="showcase">
          <img
            className="ant-designcar-outlined-icon"
            loading="lazy"
            alt=""
            src="/antdesigncaroutlined.svg"
          />
          <div className="apr-pm" />
          <div className="day-ago" />
          <div className="cars-wrapper">
            <div className="cars">
              <p className="p1">
                <b>50+</b>
              </p>
              <p className="cars1">Cars</p>
            </div>
          </div>
        </div>
        <div className="showcase1">
          <div className="component" />
          <div className="component1" />
          <div className="vector-wrapper2">
            <img
              className="vector-icon11"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
          </div>
          <div className="brand">
            <p className="p2">
              <b>50+</b>
            </p>
            <p className="brand1">Brand</p>
          </div>
        </div>
        <div className="showcase-wrapper">
          <div className="showcase2">
            <div className="icbaseline-category-wrapper">
              <img
                className="icbaseline-category-icon"
                loading="lazy"
                alt=""
                src="/icbaselinecategory.svg"
              />
            </div>
            <div className="showcase-child" />
            <div className="showcase-item" />
            <div className="types">
              <p className="p3">
                <b>50+</b>
              </p>
              <p className="types1">Types</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent3.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent3;
