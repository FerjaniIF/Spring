import "./CarUpdate.css";
import PropTypes from "prop-types";

const CarUpdate = ({ className = "" }) => {
  return (
    <div className={`carupdate ${className}`}>
      <main className="update-details">
        <div className="update-details-child" />
        <div className="update-details-item" />
        <img className="update-details-inner" alt="" src="/rectangle-18.svg" />
        <img className="update-details-child1" alt="" src="/rectangle-18.svg" />
        <div className="update-details-child2" />
        <div className="arrow-39-parent">
          <img
            className="arrow-39-icon3"
            loading="lazy"
            alt=""
            src="/arrow391.svg"
          />
          <div className="frame-wrapper4">
            <div className="pngegg-2-2-parent">
              <img
                className="pngegg-2-21"
                loading="lazy"
                alt=""
                src="/pngegg-2-2@2x.png"
              />
              <div className="frame-wrapper5">
                <div className="frame-parent14">
                  <div className="honda-civic-parent">
                    <b className="honda-civic1">2016 Honda Civic</b>
                    <div className="line-frame">
                      <div className="frame-child12" />
                    </div>
                  </div>
                  <div className="frame-wrapper6">
                    <div className="frame-parent15">
                      <div className="users-account-wrapper">
                        <img
                          className="users-account2"
                          loading="lazy"
                          alt=""
                          src="/users--account2.svg"
                        />
                      </div>
                      <div className="doors-5-seats1">4 Doors, 5 Seats</div>
                    </div>
                  </div>
                  <div className="frame-wrapper7">
                    <div className="frame-parent16">
                      <div className="user-interface-petrol-pump-wrapper">
                        <img
                          className="user-interface-petrol-pump2"
                          loading="lazy"
                          alt=""
                          src="/user-interface--petrol-pump2.svg"
                        />
                      </div>
                      <div className="regular-gasoline-871">
                        Regular Gasoline (87 Octane)
                      </div>
                    </div>
                  </div>
                  <div className="frame-parent17">
                    <div className="frame-wrapper8">
                      <div className="ellipse-parent1">
                        <div className="frame-child13" />
                        <div className="frame-child14" />
                        <div className="frame-child15" />
                        <div className="frame-child16" />
                        <div className="frame-child17" />
                      </div>
                    </div>
                    <div className="automatic1">Automatic</div>
                  </div>
                  <div className="frame-wrapper9">
                    <div className="frame-parent18">
                      <div className="transport-car-wrapper">
                        <img
                          className="transport-car2"
                          loading="lazy"
                          alt=""
                          src="/transport--car2.svg"
                        />
                      </div>
                      <div className="economy1">Economy</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="update-details-inner1">
          <div className="rectangle-parent1">
            <div className="frame-child18" />
            <div className="frame-wrapper10">
              <div className="frame-parent19">
                <div className="frame-wrapper11">
                  <button className="frame-button">
                    <div className="frame-child19" />
                    <b className="reservation1">RESERVATION</b>
                  </button>
                </div>
                <div className="frame-parent20">
                  <div className="frame-parent21">
                    <div className="pick-up-wrapper">
                      <div className="pick-up1">Pick up</div>
                    </div>
                    <div className="vector-group">
                      <img
                        className="frame-child20"
                        alt=""
                        src="/rectangle-61.svg"
                      />
                      <img
                        className="solidnavigationmap-location-icon2"
                        alt=""
                        src="/solidnavigationmaplocation1.svg"
                      />
                    </div>
                  </div>
                  <div className="frame-parent22">
                    <div className="return-container">
                      <div className="return1">Return</div>
                    </div>
                    <div className="vector-parent1">
                      <img
                        className="frame-child21"
                        alt=""
                        src="/rectangle-61.svg"
                      />
                      <img
                        className="solidnavigationmap-location-icon3"
                        alt=""
                        src="/solidnavigationmaplocation1.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="frame-parent23">
                  <div className="frame-wrapper12">
                    <div className="start-parent">
                      <div className="start1">Start</div>
                      <div className="frame-wrapper13">
                        <div className="end-parent">
                          <div className="end1">End</div>
                          <div className="frame-parent24">
                            <div className="first-name-parent">
                              <div className="first-name">First Name</div>
                              <div className="last-name">Last Name</div>
                            </div>
                            <div className="email2">Email</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame-parent25">
                    <div className="vector-parent2">
                      <img
                        className="frame-child22"
                        alt=""
                        src="/rectangle-61.svg"
                      />
                      <img
                        className="business-calendar2"
                        loading="lazy"
                        alt=""
                        src="/business--calendar1.svg"
                      />
                    </div>
                    <div className="frame-parent26">
                      <div className="vector-parent3">
                        <img
                          className="frame-child23"
                          alt=""
                          src="/rectangle-18.svg"
                        />
                        <img
                          className="business-calendar3"
                          loading="lazy"
                          alt=""
                          src="/business--calendar1.svg"
                        />
                      </div>
                      <img
                        className="frame-child24"
                        loading="lazy"
                        alt=""
                        src="/rectangle-18.svg"
                      />
                      <div className="vector-wrapper1">
                        <img
                          className="frame-child25"
                          loading="lazy"
                          alt=""
                          src="/rectangle-18.svg"
                        />
                      </div>
                      <img
                        className="frame-child26"
                        loading="lazy"
                        alt=""
                        src="/rectangle-18.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="frame-wrapper14">
                  <div className="frame-parent27">
                    <div className="frame-wrapper15">
                      <div className="total-parent">
                        <div className="total-1">{`Total - `}</div>
                        <div className="dt">2400 DT</div>
                      </div>
                    </div>
                    <div className="vector-parent4">
                      <img
                        className="frame-child27"
                        alt=""
                        src="/rectangle-102.svg"
                      />
                      <div className="cost-details1">Cost details</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="frame-parent28">
              <div className="group-div">
                <div className="frame-child28" />
                <h3 className="update">
                  <p className="update1">Update</p>
                </h3>
              </div>
              <button className="cancel-button1">
                <div className="cancel-button-item" />
                <b className="cancel-reservation">Cancel Reservation</b>
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

CarUpdate.propTypes = {
  className: PropTypes.string,
};

export default CarUpdate;
