import React, { useState } from "react";
import "./Page.css";
import PropTypes from "prop-types";

const Page = ({ className = "" }) => {
  const [formData, setFormData] = useState({
    model: "",
    price: "",
    mode: "",
    category: "",
    fuelType: "",
    carId: ""
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleBook = (event) => {
    event.preventDefault();
    console.log("Booking car with ID:", formData.carId);
    // Add your booking logic here
  };

  return (
    <form onSubmit={handleBook}>
      <section className={`page ${className}`}>
        <div className="content1">
          <h1 className="mycarnow1">MyCarNow</h1>
          <div className="car-details1">
            <div className="car-info1">
              <div className="car-model-brand">
                <div className="model-brand-row">
                  <div className="model-brand-row-child" />
                  <div className="model">{`Model `}</div>
                  <div className="form-group">
                    <input
                      type="text"
                      name="model"
                      value={formData.model}
                      onChange={handleInputChange}
                      placeholder="Model"
                      className="form-control"
                    />
                  </div>
                </div>
                <div className="model-brand-row1">
                  <div className="model-brand-row-item" />
                  <div className="brand2">Brand</div>
                  <img className="icon29" alt="" src="/1353309200-3@2x.png" />
                </div>
              </div>
              <button className="reservations">
                <img
                  className="reservations-child"
                  alt=""
                  src="/rectangle-10.svg"
                />
                <div className="my-reservations1">My Reservations</div>
              </button>
            </div>
          </div>
        </div>
        <div className="page-inner">
          <div className="auto-parent">
            <b className="auto1">Auto</b>
            <b className="petrol1">Petrol</b>
            <b className="k1">{`5 K `}</b>
            <div className="frame-child30" />
            <div className="car-item">
              <div className="car-details-wrapper">
                <div className="car-description">
                  <h3 className="honda-civic2">Honda Civic</h3>
                  <div className="car-image-wrapper">
                    <img className="pngegg-2-1" alt="" src="/pngegg-2-1@2x.png" />
                    <img
                      className="car-image-wrapper-child"
                      loading="lazy"
                      alt=""
                      src="/group-409.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="car-rental-info">
                <div className="rental-duration">
                  <div className="day1">
                    <b>{`$ 20 `}</b>
                    <span className="day2">/ day</span>
                  </div>
                </div>
                <img
                  className="info-separator-icon"
                  loading="lazy"
                  alt=""
                  src="/line-6.svg"
                />
                <div className="rental-details">
                  <div className="transport-icon-wrapper">
                    <button className="transport-icon-container">
                      <img
                        className="transport-car3"
                        alt=""
                        src="/transport--car.svg"
                      />
                    </button>
                    <img
                      className="empty-state-icon"
                      loading="lazy"
                      alt=""
                      src="/frame.svg"
                    />
                    <div className="fuel-icon-wrapper">
                      <img
                        className="icround-local-gas-station-icon"
                        loading="lazy"
                        alt=""
                        src="/icroundlocalgasstation.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="car-booking">
              <div className="booking-info">
                <div className="fuel-type1">
                  <div className="economy-petrol-wrapper">
                    <div className="economy-petrol">
                      <b className="economy2">Economy</b>
                      <div className="auto-label-wrapper">
                        <b className="auto2">Auto</b>
                      </div>
                      <b className="petrol2">Petrol</b>
                    </div>
                  </div>
                  <div className="booking-separator" />
                </div>
                <div className="book-button-wrapper">
                  <button className="group-button" type="submit">
                    <div className="frame-child31" />
                    <b className="book">Book</b>
                  </button>
                </div>
              </div>
            </div>
            <div className="form-group">
              <input
                type="text"
                name="price"
                value={formData.price}
                onChange={handleInputChange}
                placeholder="Price"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="mode"
                value={formData.mode}
                onChange={handleInputChange}
                placeholder="Mode"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                placeholder="Category"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="fuelType"
                value={formData.fuelType}
                onChange={handleInputChange}
                placeholder="Fuel Type"
                className="form-control"
              />
            </div>
          </div>
        </div>
      </section>
    </form>
  );
};

Page.propTypes = {
  className: PropTypes.string,
};

export default Page;
