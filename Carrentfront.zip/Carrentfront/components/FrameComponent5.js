import "./FrameComponent5.css";
import PropTypes from 'prop-types';


const FrameComponent = ({ className = "" }) => {
  return (
    <div className={`frame-wrapper20 ${className}`}>
      <div className="frame-parent37">
        <div className="basic-wrapper">
          <div className="basic">
            <div className="basic-child" />
            <div className="akar-iconscheck" />
            <div className="basic-parent">
              <b className="basic1">Basic</b>
              <div className="a-day-parent">
                <b className="a-day">
                  <span>{`$24/ `}</span>
                  <span className="a-day1">a day</span>
                </b>
                <div className="checkbox-parent">
                  <img
                    className="checkbox-icon1"
                    loading="lazy"
                    alt=""
                    src="/checkbox.svg"
                  />
                  <div className="economy-class-car-wrapper">
                    <div className="economy-class-car">Economy Class Car</div>
                  </div>
                </div>
                <div className="checkbox-group">
                  <img className="checkbox-icon2" alt="" src="/checkbox.svg" />
                  <div className="gps-system-wrapper">
                    <div className="gps-system">GPS System</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="checkbox-container">
              <img className="checkbox-icon3" alt="" src="/checkbox.svg" />
              <div className="one-coupon-for-next-rental-wrapper">
                <div className="one-coupon-for">One Coupon for next rental</div>
              </div>
            </div>
          </div>
        </div>
        <div className="premium">
          <div className="premium-child" />
          <b className="premium1">Premium</b>
          <div className="akar-iconscheck1" />
          <div className="a-month-parent">
            <b className="a-month">
              <span>{`$50/ `}</span>
              <span className="a-month1">a month</span>
            </b>
            <div className="checkbox-parent1">
              <img className="checkbox-icon4" alt="" src="/checkbox.svg" />
              <div className="n-publishing-and-graphic-wrapper">
                <div className="n-publishing-and">n publishing and graphic</div>
              </div>
            </div>
            <div className="frame-parent38">
              <div className="checkbox-parent2">
                <img className="checkbox-icon5" alt="" src="/checkbox.svg" />
                <div className="n-publishing-and-graphic-container">
                  <div className="n-publishing-and1">
                    n publishing and graphic
                  </div>
                </div>
              </div>
              <div className="frame-parent39">
                <div className="checkbox-parent3">
                  <img className="checkbox-icon6" alt="" src="/checkbox.svg" />
                  <div className="n-publishing-and-graphic-frame">
                    <div className="n-publishing-and2">
                      n publishing and graphic
                    </div>
                  </div>
                </div>
                <div className="checkbox-parent4">
                  <img className="checkbox-icon7" alt="" src="/checkbox.svg" />
                  <div className="n-publishing-and-graphic-wrapper1">
                    <div className="n-publishing-and3">
                      n publishing and graphic
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="checkbox-parent5">
            <img className="checkbox-icon8" alt="" src="/checkbox.svg" />
            <div className="n-publishing-and-graphic-wrapper2">
              <div className="n-publishing-and4">n publishing and graphic</div>
            </div>
          </div>
        </div>
        <div className="ultra">
          <div className="ultra-child" />
          <b className="ultra1">Ultra</b>
          <div className="akar-iconscheck2" />
          <div className="months-parent">
            <b className="months">
              <span className="months-txt">
                <span>{`$80/ `}</span>
                <span className="months1"> 3 months</span>
              </span>
            </b>
            <div className="checkbox-parent6">
              <img className="checkbox-icon9" alt="" src="/checkbox.svg" />
              <div className="n-publishing-and-graphic-wrapper3">
                <div className="n-publishing-and5">
                  n publishing and graphic
                </div>
              </div>
            </div>
            <div className="frame-parent40">
              <div className="checkbox-parent7">
                <img className="checkbox-icon10" alt="" src="/checkbox.svg" />
                <div className="n-publishing-and-graphic-wrapper4">
                  <div className="n-publishing-and6">
                    n publishing and graphic
                  </div>
                </div>
              </div>
              <div className="frame-parent41">
                <div className="checkbox-parent8">
                  <img className="checkbox-icon11" alt="" src="/checkbox.svg" />
                  <div className="n-publishing-and-graphic-wrapper5">
                    <div className="n-publishing-and7">
                      n publishing and graphic
                    </div>
                  </div>
                </div>
                <div className="checkbox-parent9">
                  <img className="checkbox-icon12" alt="" src="/checkbox.svg" />
                  <div className="n-publishing-and-graphic-wrapper6">
                    <div className="n-publishing-and8">
                      n publishing and graphic
                    </div>
                  </div>
                </div>
                <div className="checkbox-parent10">
                  <img className="checkbox-icon13" alt="" src="/checkbox.svg" />
                  <div className="n-publishing-and-graphic-wrapper7">
                    <div className="n-publishing-and9">
                      n publishing and graphic
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="checkbox-parent11">
            <img className="checkbox-icon14" alt="" src="/checkbox-13.svg" />
            <div className="n-publishing-and-graphic-wrapper8">
              <div className="n-publishing-and10">n publishing and graphic</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
