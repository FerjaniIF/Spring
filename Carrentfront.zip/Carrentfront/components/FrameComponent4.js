import "./FrameComponent4.css";
import PropTypes from 'prop-types';

const FrameComponent4 = ({ className = "" }) => {
  return (
    <section className={`navigation-parent ${className}`}>
      <div className="frame-wrapper17">
        <div className="travel-around-by-premium-cars-parent">
          <h1 className="travel-around-by">Travel around by Premium Cars</h1>
          <div className="get-started-btn-wrapper">
            <button className="get-started-btn">
              <div className="get-started-btn-child" />
              <div className="get-started">Get Started</div>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent4.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent4;
