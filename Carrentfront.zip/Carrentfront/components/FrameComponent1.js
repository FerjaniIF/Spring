import "./FrameComponent1.css";
import PropTypes from "prop-types";


const FrameComponent1 = ({ className = "" }) => {
  return (
    <section className={`adminlogin-inner ${className}`}>
      <div className="frame-parent29">
        <div className="frame-wrapper16">
          <div className="accounticon-group">
            <img
              className="accounticon2"
              loading="lazy"
              alt=""
              src="/accounticon.svg"
            />
            <div className="user-interface-cancel-container">
              <img
                className="user-interface-cancel1"
                loading="lazy"
                alt=""
                src="/user-interface--cancel.svg"
              />
            </div>
          </div>
        </div>
        <b className="admin-login">Admin Login</b>
      </div>
    </section>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent1;
