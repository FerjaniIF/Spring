import "./Footer2.css";
import PropTypes from "prop-types";

const Footer = ({ className = "" }) => {
  return (
    <div className={`footer2 ${className}`}>
      <div className="navigation1">
        <div className="ellipse-parent3">
          <div className="frame-child37" />
          <div className="frame">
            <b className="b8">1</b>
          </div>
        </div>
        <div className="navigation-items">
          <b className="navigation-dots">2</b>
        </div>
        <div className="navigation-items1">
          <b className="b9">3</b>
        </div>
        <div className="navigation-items2">
          <b className="b10">4</b>
        </div>
        <div className="navigation-items3">
          <b className="b11">5</b>
        </div>
        <div className="navigation-items4">
          <b className="b12">6</b>
        </div>
        <div className="navigation-items5">
          <b className="b13">7</b>
        </div>
        <div className="navigation-items6">
          <b className="b14">8</b>
        </div>
        <div className="navigation-items7">
          <b className="b15">9</b>
        </div>
        <div className="navigation-items8">
          <div className="dot-parent">
            <b className="dot">10</b>
            <img
              className="dot-icon"
              loading="lazy"
              alt=""
              src="/1146451200-1@2x.png"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
