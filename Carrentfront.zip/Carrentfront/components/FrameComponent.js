import "./FrameComponent.css";
import PropTypes from "prop-types";


const FrameComponent = ({ className = "" }) => {
  return (
    <section className={`frame-section ${className}`}>
      <div className="password-container">
        <b className="password3">Password</b>
      </div>
      <div className="rectangle-parent2">
        <div className="frame-child29" />
        <img
          className="outlinestatuseye-closed-icon3"
          loading="lazy"
          alt=""
          src="/outlinestatuseyeclosed.svg"
        />
      </div>
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
