import ReservationsContent from "../components/ReservationsContent";
import Footer from "../components/Footer2";
import "./MyReservations.css";
import PropTypes from "prop-types";

const MyReservations = () => {
  return (
    <div className="myreservations">
      <main className="my-reservations">
        <div className="my-reservations-child" />
        <div className="my-reservations-item" />
        <div className="my-reservations-inner" />
        <img className="icon" alt="" src="/1682125200-1@2x.png" />
        <div className="my-reservations-child1" />
        <img className="group-icon" alt="" />
        <img className="vector-icon" alt="" />
        <img className="vector-icon1" alt="" />
        <img className="vector-icon2" alt="" />
        <img className="vector-icon3" alt="" />
        <img className="vector-icon4" alt="" />
        <img className="vector-icon5" alt="" />
        <img className="vector-icon6" alt="" />
        <img className="vector-icon7" alt="" />
        <img className="vector-icon8" alt="" />
        <img className="vector-icon9" alt="" />
        <img className="vector-icon10" alt="" />
        <img className="icon1" alt="" src="/1353309200-5@2x.png" />
        <img className="icon2" alt="" src="/119232200-2@2x.png" />
        <img className="icon3" alt="" src="/119232200-3@2x.png" />
        <img className="icon4" alt="" src="/1888022200-1@2x.png" />
        <img className="icon5" alt="" src="/1888022200-1@2x.png" />
        <img className="icon6" alt="" src="/1888022200-1@2x.png" />
        <img className="icon7" alt="" src="/1888022200-1@2x.png" />
        <img className="line-icon" alt="" />
        <img className="my-reservations-child2" alt="" />
        <img className="my-reservations-child3" alt="" />
        <img className="icon8" alt="" src="/1047150200-1@2x.png" />
        <img className="icon9" alt="" src="/1047150200-1@2x.png" />
        <img className="icon10" alt="" src="/1047150200-1@2x.png" />
        <img className="icon11" alt="" src="/1047150200-1@2x.png" />
        <img className="icon12" alt="" src="/1047150200-1@2x.png" />
        <img className="icon13" alt="" src="/1047150200-1@2x.png" />
        <img className="icon14" alt="" src="/3058943200-2@2x.png" />
        <img className="icon15" alt="" src="/3058943200-4@2x.png" />
        <img className="icon16" alt="" src="/3058943200-6@2x.png" />
        <img className="icon17" alt="" src="/3058943200-7@2x.png" />
        <img className="icon18" alt="" src="/3058943200-5@2x.png" />
        <img className="icon19" alt="" src="/27132200-1@2x.png" />
        <img className="icon20" alt="" src="/27132200-3@2x.png" />
        <img className="icon21" alt="" src="/27132200-5@2x.png" />
        <img className="icon22" alt="" src="/27132200-6@2x.png" />
        <img className="icon23" alt="" src="/27132200-4@2x.png" />
        <img className="icon24" alt="" src="/1907976200-2@2x.png" />
        <img className="icon25" alt="" src="/1907976200-2@2x.png" />
        <img className="icon26" alt="" src="/1907976200-2@2x.png" />
        <img className="icon27" alt="" src="/1907976200-2@2x.png" />
        <img className="icon28" alt="" src="/1907976200-2@2x.png" />
        <img className="icon-park-outlinespeed-one" alt="" />
        <img className="icon-park-outlinespeed-one1" alt="" />
        <img className="icon-park-outlinespeed-one2" alt="" />
        <img className="my-reservations-child4" alt="" />
        <img className="icon-park-outlinespeed-one3" alt="" />
        <img className="icon-park-outlinespeed-one4" alt="" />
        <b className="auto">Auto</b>
        <b className="petrol">Petrol</b>
        <b className="k">{`5 K `}</b>
        <ReservationsContent />
        <Footer />
      </main>
    </div>
  );
};

export default MyReservations;
