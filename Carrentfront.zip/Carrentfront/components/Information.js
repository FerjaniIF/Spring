import "./Information.css";
import PropTypes from "prop-types";

const Information = ({ className = "" }) => {
  return (
    <header className={`information ${className}`}>
      <div className="title">
        <div className="catchphrase">
          <div className="catchphrase-child" />
          <div className="div1">1</div>
        </div>
        <div className="description">
          <i className="please-fill-out">
            PLease fill out this Information in order to serve the desired car
          </i>
        </div>
      </div>
    </header>
  );
};

Information.propTypes = {
  className: PropTypes.string,
};

export default Information;
