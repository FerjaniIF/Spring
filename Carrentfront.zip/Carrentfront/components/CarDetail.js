import "./CarDetail.css";
import PropTypes from "prop-types";


const CarDetail = ({ className = "" }) => {
  return (
    <div className={`cardetail ${className}`}>
      <main className="car-detail">
        <header className="rectangle-group">
          <div className="rectangle-div" />
          <img className="rectangle-icon" alt="" src="/rectangle-40.svg" />
        </header>
        <div className="main-content-parent">
          <div className="main-content">
            <div className="car-info">
              <div className="car-details">
                <div className="car-name">
                  <img
                    className="arrow-39-icon"
                    loading="lazy"
                    alt=""
                    src="/arrow39.svg"
                  />
                  <div className="back-wrapper">
                    <b className="back">Back</b>
                  </div>
                </div>
              </div>
              <div className="car-image">
                <b className="honda-civic">2016 Honda Civic</b>
                <div className="image-container">
                  <img className="pngegg-2-2" alt="" src="/pngegg-2-2@2x.png" />
                  <img
                    className="pngegg-1-1"
                    loading="lazy"
                    alt=""
                    src="/pngegg-1-1@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="dt-day-parent">
            <b className="dt-day">
              <span>20DT</span>
              <span className="day"> /day</span>
            </b>
            <b className="price">Price</b>
            <img
              className="shopping-tag"
              loading="lazy"
              alt=""
              src="/shopping--tag.svg"
            />
          </div>
        </div>
        <div className="specifications-content-wrapper">
          <div className="specifications-content">
            <div className="specifications-details">
              <div className="specification-items">
                <b className="specifications">Specifications</b>
                <div className="specification-list">
                  <div className="specification-item-one">
                    <div className="fuel-type">
                      <img
                        className="users-account"
                        loading="lazy"
                        alt=""
                        src="/users--account.svg"
                      />
                      <img
                        className="user-interface-petrol-pump"
                        loading="lazy"
                        alt=""
                        src="/user-interface--petrol-pump.svg"
                      />
                      <div className="fuel-icon">
                        <div className="fuel-icon-child" />
                        <div className="fuel-icon-item" />
                        <div className="fuel-icon-inner" />
                        <div className="fuel-icon-child1" />
                        <div className="fuel-icon-child2" />
                      </div>
                    </div>
                    <div className="specification-item-two">
                      <div className="doors-seats-container">
                        <div className="doors-5-seats">4 Doors, 5 Seats</div>
                      </div>
                      <div className="octane-container">
                        <div className="regular-gasoline-87">
                          Regular Gasoline (87 Octane)
                        </div>
                        <div className="automatic-container">
                          <div className="automatic">Automatic</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="economy-info">
              <div className="gas-v6-container">
                <ul className="gas-v6-15l-front-wheel-driv">
                  <li className="gas-v6">Gas V6 , 1.5L</li>
                  <li className="front-wheel-drive">Front Wheel Drive</li>
                  <li className="continously-variable-automatic">
                    Continously Variable Automatic Transmission(CVT)
                  </li>
                  <li className="wheel-anti-lock-braking">
                    4 wheel Anti-lock Braking System (ABS)
                  </li>
                  <li className="driver-side-front-aribag">
                    Driver-side front aribag
                  </li>
                  <li className="front-curtain">Front curtain airbags</li>
                  <li className="front-side-airbags">Front side airbags</li>
                  <li className="traction-control">Traction Control</li>
                  <li>Stability Control</li>
                </ul>
              </div>
              <div className="economy">Economy</div>
              <img
                className="transport-car"
                loading="lazy"
                alt=""
                src="/transport--car.svg"
              />
              <div className="reserve-button-container">
                <div className="reserve-cancel-buttons">
                  <button className="reserve-button">
                    <div className="reserve-button-child" />
                    <b className="reserve">{`Reserve `}</b>
                  </button>
                  <button className="cancel-button">
                    <div className="cancel-button-child" />
                    <b className="cancel">Cancel</b>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

CarDetail.propTypes = {
  className: PropTypes.string,
};

export default CarDetail;
