import FrameComponent2 from "./FrameComponent2";
import PropTypes from "prop-types";
import "./FrameComponent11.css";

const FrameComponent1 = ({ className = "" }) => {
  return (
    <div className={`frame-wrapper18 ${className}`}>
      <div className="frame-parent33">
        <div className="why-choose-rental-wrapper">
          <h1 className="why-choose-rental">Why Choose Rental?</h1>
        </div>
        <div className="frame-parent34">
          <div className="frame-parent35">
            <div className="frame-parent36">
              <div className="iocn-container-container">
                <img
                  className="iocn-container-icon1"
                  loading="lazy"
                  alt=""
                  src="/iocn-container.svg"
                />
              </div>
              <h3 className="fast-easy">{`Fast &  Easy Booking`}</h3>
            </div>
            <div className="book-your-car">
              Book your car online. Follow the easy process to book your car
              online. Or just call us anytime from anywhere
            </div>
          </div>
          <FrameComponent2
            iocnContainer="/iocn-container-1.svg"
            manyPickupLocation="Many Pickup Location"
            weHaveAnExtensiveNumberOf="We have an extensive number of cars that will be available to pick up from any location throughout the country."
          />
          <div className="frame-wrapper19">
            <FrameComponent2
              iocnContainer="/iocn-container-2.svg"
              manyPickupLocation="Satisifed Customers"
              weHaveAnExtensiveNumberOf="We have 70,000+ happy customers ahnd it’s increasing."
              propWidth="unset"
              propAlignSelf="stretch"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent1;
