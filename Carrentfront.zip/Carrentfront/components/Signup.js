import "./Signup.css";

const Signup = ({ className = "" }) => {
  return (
    <form className={`signup ${className}`}>
      <div className="background1" />
      <section className="close-button">
        <div className="account-icon-parent">
          <div className="account-icon">
            <div className="close-icon">
              <div className="account-info">
                <img
                  className="accounticon"
                  loading="lazy"
                  alt=""
                  src="/accounticon1.svg"
                />
              </div>
              <img
                className="user-interface-close"
                loading="lazy"
                alt=""
                src="/user-interface--close.svg"
              />
            </div>
          </div>
          <h3 className="create-your-account">Create your Account</h3>
        </div>
      </section>
      <input className="name-input" placeholder="Name" type="text" />
      <input className="email-input" placeholder="Email Address" type="text" />
      <div className="phone-input">
        <div className="phonenumber">
          <div className="phonenumber-child" />
          <div className="phone-input-prefix">
            <div className="country-code">
              <b className="country-code-placeholder">+216</b>
              <div className="arrows-upper-arrow-wrapper">
                <img
                  className="arrows-upper-arrow"
                  alt=""
                  src="/arrows--upper-arrow.svg"
                />
              </div>
            </div>
          </div>
          <div className="phone-icon">
            <img
              className="phone-input-icon"
              alt=""
              src="/phone-input-icon.svg"
            />
          </div>
          <div className="phone-label">
            <b className="phone-number">Phone number</b>
          </div>
        </div>
      </div>
      <div className="location-input">
        <div className="location-fields">
          <input className="country" placeholder="Country" type="text" />
          <input className="city" placeholder="City" type="text" />
        </div>
      </div>
      <div className="password-input">
        <div className="password">
          <div className="password-child" />
          <input className="password1" placeholder="Password" type="text" />
          <div className="eye-icon">
            <img
              className="outlinestatuseye-closed-icon"
              alt=""
              src="/outlinestatuseyeclosed1.svg"
            />
          </div>
        </div>
      </div>
      <div className="password-input1">
        <div className="re-enterpassword">
          <div className="re-enterpassword-child" />
          <input
            className="reenter-password"
            placeholder="Reenter Password"
            type="text"
          />
          <div className="outlinestatuseye-closed-wrapper">
            <img
              className="outlinestatuseye-closed-icon1"
              alt=""
              src="/outlinestatuseyeclosed-1.svg"
            />
          </div>
        </div>
      </div>
      <footer className="terms-checkbox">
        <div className="agreement">
          <div className="checkbox-icon">
            <div className="checkbox-graphic">
              <img className="shapes-shape" alt="" src="/shapes--shape.svg" />
              <div className="terms-and-conditions">
                <div className="i-accept-the-container">
                  <p className="i-accept-the-terms-and-conditi">
                    <span className="i-accept-the">I accept the</span>
                    <b className="terms-and-conditions1">
                      <span className="span">{` `}</span>
                      <span className="terms-and-conditions2">
                        terms and conditions
                      </span>
                    </b>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <button className="signup1">
            <div className="signup-child" />
            <b className="sign-up">Sign up</b>
          </button>
        </div>
      </footer>
    </form>
  );
};

Signup.propTypes = {
  className: PropTypes.string,
};

export default Signup;
