import "./Login.css";
import "./Signup.css";
import { Link } from 'react-router-dom';
import PropTypes from "prop-types";
import { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";


const Login = ({ className = "" }) => {

  const [formData, setFormData] = useState({
    username: "",
    password: ""
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const navigate = useNavigate();

  const handleSubmit = async(e) =>{
    e.preventDefault();
    console.log(formData);
    try {
      const response = await fetch("http://localhost:8001/api/auth/login" , {
        method : "POST",
        headers : { "Content-Type": "application/json"},
        body : JSON.stringify(formData)
      });

      const data = await response.json();
      console.log("User created : ", data);
      navigate("/List-cars")
    } catch (error) {
      console.log("Error creating a client" , error.message);
    }
  }
  
  return (
    <Form onSubmit={handleSubmit}>
      <section className="signup11">
        <div className="background2" />
        <div className="characters">(8+ characters)</div>
        <div className="left">
          <img className="left-child" alt="" src="/rectangle-14@2x.png" />
          <div className="frame-container">
            <div className="security-shield-wrapper">
              <img
                className="security-shield"
                loading="lazy"
                alt=""
                src="/security--shield.svg"
              />
            </div>
            <h3 className="secure-payments-through">
              Secure payments through reliable partners
            </h3>
          </div>
          <div className="user-interface-thunder-parent">
            <img
              className="user-interface-thunder"
              loading="lazy"
              alt=""
              src="/user-interface--thunder.svg"
            />
            <h3 className="fast-services">
              <p className="fast-services1">Fast services</p>
            </h3>
          </div>
          <div className="frame-div">
            <div className="business-percentage-parent">
              <img
                className="business-percentage"
                loading="lazy"
                alt=""
                src="/business--percentage.svg"
              />
              <h3 className="fair-commisions">Fair Commisions</h3>
            </div>
            <div className="business-dollar-parent">
              <img
                className="business-dollar"
                loading="lazy"
                alt=""
                src="/business--dollar.svg"
              />
              <div className="best-available-rates-wrapper">
                <h3 className="best-available-rates">Best Available Rates</h3>
              </div>
            </div>
          </div>
          <div className="left-inner">
            <div className="user-interface-like-parent">
              <img
                className="user-interface-like"
                loading="lazy"
                alt=""
                src="/user-interface--like.svg"
              />
              <div className="convenience-wrapper">
                <h3 className="convenience">
                  <p className="convenience1">Convenience</p>
                </h3>
              </div>
            </div>
          </div>
        </div>
        <div className="signup1-inner">
          <div className="frame-parent1">
            <div className="frame-wrapper">
              <div className="frame-parent2">
                <div className="frame-parent3">
                  <div className="frame-parent4">
                    <div className="accounticon-parent">
                      <img
                        className="accounticon1"
                        loading="lazy"
                        alt=""
                        src="/accounticon.svg"
                      />
                      <button className="log-in-wrapper">
                        <b className="log-in">Log in</b>
                      </button>
                    </div>
                  </div>
                  <div className="frame-wrapper1">
                    <div className="frame-parent5 ">

                    <Form.Group controlId="formSign">
                      <Form.Control
                        className="email-input"
                        placeholder="Email Address"
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                    <Form.Group controlId="formSign">
                      <Form.Control
                        className="email-input"
                        placeholder="Password"
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                      
                    </div>
                  </div>
                </div>
                <div className="signinbutton-container">
                    <div className="signinbutton-item" />
                    <Button className="signinbutton1 log-in1 log-in2" component={Link} to="/CarsList">
                      Log in
                    </Button>
                </div>
              </div>
            </div>
            <div className="frame-parent6">
              <div className="frame-parent7">
                <div className="line-wrapper">
                  <div className="line-div" />
                </div>
                <h3 className="or">or</h3>
                <div className="line-container">
                  <div className="frame-child1" />
                </div>
              </div>
              <div className="frame-wrapper2">
                <div className="frame-parent8">
                  <div className="frame-wrapper3">
                    <div className="frame-parent9">
                      <button className="ellipse-parent">
                        <div className="ellipse-div" />
                        <img
                          className="outlinestatuskey-icon"
                          alt=""
                          src="/outlinestatuskey@2x.png"
                        />
                      </button>
                      <div className="sso-wrapper">
                        <div className="sso">SSO</div>
                      </div>
                    </div>
                  </div>
                  <div className="facebook-parent">
                    <img
                      className="facebook-icon"
                      loading="lazy"
                      alt=""
                      src="/facebook.svg"
                    />
                    <div className="facebook-wrapper">
                      <div className="facebook">Facebook</div>
                    </div>
                  </div>
                  <div className="frame-parent10">
                    <div className="ellipse-group">
                      <div className="frame-child2" />
                      <div className="wrapper-outlinebrandsgoogle-">
                        <img
                          className="outlinebrandsgoogle-alt-icon"
                          loading="lazy"
                          alt=""
                          src="/outlinebrandsgooglealt.svg"
                        />
                      </div>
                    </div>
                    <div className="google-wrapper">
                      <div className="google">
                        <p className="google1">Google</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Form>
  );
};

Login.propTypes = {
  className: PropTypes.string,
};

export default Login;
