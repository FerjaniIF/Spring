import Page from "../components/Page";
import Footer from "../components/Footer1";
import "./CarsList.css";

const CarsList = () => {
  return (
    <div className="carslist">
      <main className="carslist1">
        <Page />
        <Footer />
      </main>
    </div>
  );
};

export default CarsList;
