import "./ConfirmReservation.css";
import PropTypes from "prop-types";


const ConfirmReservation = ({ className = "" }) => {
  return (
    <div className={`confirmreservation ${className}`}>
      <main className="confirmation-page">
        <div className="confirmation-page-child" />
        <header className="confirmation-page-header">
          <button className="vector-parent">
            <img className="frame-child3" alt="" src="/rectangle-401.svg" />
            <img className="arrow-39-icon2" alt="" src="/arrow39.svg" />
            <div className="back-button1">
              <b className="back2">Back</b>
            </div>
          </button>
          <div className="confirmation-page-image">
            <div className="vehicle-image">
              <div className="vehicle-image-child" />
              <div className="vehicle-image-name-container">
                <span className="vehicle-image-name-container1">
                  <p className="p">2</p>
                </span>
              </div>
            </div>
          </div>
        </header>
        <section className="reservation-details-wrapper">
          <div className="reservation-details">
            <div className="vehicle-details">
              <div className="vehicle-type-details-wrapper">
                <div className="vehicle-type-details">
                  <div className="vehicle-type">
                    <img
                      className="vehicle-type-icon"
                      loading="lazy"
                      alt=""
                      src="/rectangle-24@2x.png"
                    />
                    <div className="vehicle-type-name">
                      <h1 className="mercedes-suv">Mercedes (SUV)</h1>
                    </div>
                  </div>
                  <div className="cost-calculation-wrapper">
                    <div className="cost-calculation">
                      <div className="cost-calculation-details">
                        <img
                          className="users-account1"
                          loading="lazy"
                          alt=""
                          src="/users--account1.svg"
                        />
                      </div>
                      <div className="cost-calculation-details1">
                        <img
                          className="user-interface-petrol-pump1"
                          loading="lazy"
                          alt=""
                          src="/user-interface--petrol-pump1.svg"
                        />
                      </div>
                      <div className="ellipse-container">
                        <div className="frame-child4" />
                        <div className="frame-child5" />
                        <div className="frame-child6" />
                        <div className="frame-child7" />
                        <div className="cost-calculation-separator" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="reservation-confirmation">
                <div className="reservation-confirmation-child" />
                <div className="confirmation-details">
                  <div className="reservation-label-wrapper">
                    <button className="reservation-label">
                      <div className="reservation-label-child" />
                      <div className="reservation">RESERVATION</div>
                    </button>
                  </div>
                  <div className="reservation-summary">
                    <div className="frame-parent11">
                      <div className="location-details-parent">
                        <div className="location-details">
                          <img
                            className="solidnavigationmap-location-icon"
                            loading="lazy"
                            alt=""
                            src="/solidnavigationmaplocation.svg"
                          />
                          <div className="return-location">
                            <div className="pick-up">Pick up</div>
                          </div>
                        </div>
                        <button className="vector-wrapper">
                          <img
                            className="frame-child8"
                            alt=""
                            src="/rectangle-6.svg"
                          />
                        </button>
                      </div>
                      <div className="frame-parent12">
                        <div className="solidnavigationmap-location-parent">
                          <img
                            className="solidnavigationmap-location-icon1"
                            loading="lazy"
                            alt=""
                            src="/solidnavigationmaplocation.svg"
                          />
                          <div className="return-wrapper">
                            <div className="return">Return</div>
                          </div>
                        </div>
                        <button className="vector-container">
                          <img
                            className="frame-child9"
                            alt=""
                            src="/rectangle-6.svg"
                          />
                        </button>
                      </div>
                    </div>
                    <div className="frame-parent13">
                      <div className="business-calendar-parent">
                        <img
                          className="business-calendar"
                          loading="lazy"
                          alt=""
                          src="/business--calendar.svg"
                        />
                        <div className="start">Start</div>
                      </div>
                      <div className="vector-frame">
                        <img
                          className="frame-child10"
                          loading="lazy"
                          alt=""
                          src="/rectangle-6.svg"
                        />
                      </div>
                    </div>
                    <div className="reservation-end-date">
                      <div className="end-date-details">
                        <img
                          className="business-calendar1"
                          loading="lazy"
                          alt=""
                          src="/business--calendar.svg"
                        />
                        <div className="end-label">
                          <div className="end">End</div>
                        </div>
                      </div>
                      <img
                        className="reservation-end-date-child"
                        loading="lazy"
                        alt=""
                        src="/rectangle-6.svg"
                      />
                    </div>
                  </div>
                  <div className="total-cost">
                    <div className="total-cost-details">
                      <div className="total-label-wrapper">
                        <div className="total-label">
                          <div className="total-">{`Total - `}</div>
                          <div className="total">$2400</div>
                        </div>
                      </div>
                      <button className="cost-details-label">
                        <img
                          className="cost-details-label-child"
                          alt=""
                          src="/rectangle-101.svg"
                        />
                        <div className="cost-details">Cost details</div>
                      </button>
                    </div>
                  </div>
                  <div className="information-icon">
                    <div className="icon-details">
                      <div className="icon-details-child" />
                      <div className="i">i</div>
                    </div>
                  </div>
                </div>
                <div className="confirmation-button">
                  <button className="rectangle-container">
                    <div className="frame-child11" />
                    <div className="confirm">Confirm</div>
                  </button>
                </div>
              </div>
            </div>
            <div className="vehicle-icon">
              <img
                className="transport-car1"
                loading="lazy"
                alt=""
                src="/transport--car1.svg"
              />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

ConfirmReservation.propTypes = {
  className: PropTypes.string,
};

export default ConfirmReservation;
