import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const ReservationForm = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    idNumber: "",
    licenseCode: "",
    pickupLocation: "",
    pickupDateTime: "",
    dropOffDateTime: ""
  });

  const navigate = useNavigate();

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8001/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      console.log("Reservation created:", data);
      navigate("/confirmation");
    } catch (error) {
      console.log("Error creating a reservation", error.message);
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="firstName">
        <Form.Label>First Name</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter first name"
          name="firstName"
          value={formData.firstName}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="lastName">
        <Form.Label>Last Name</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter last name"
          name="lastName"
          value={formData.lastName}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="email">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="email"
          placeholder="Enter email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="phone">
        <Form.Label>Phone</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter phone"
          name="phone"
          value={formData.phone}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="idNumber">
        <Form.Label>ID Number</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter ID number"
          name="idNumber"
          value={formData.idNumber}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="licenseCode">
        <Form.Label>License Code</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter license code"
          name="licenseCode"
          value={formData.licenseCode}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="pickupLocation">
        <Form.Label>Pickup Location</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter pickup location"
          name="pickupLocation"
          value={formData.pickupLocation}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="pickupDateTime">
        <Form.Label>Pickup Date and Time</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter pickup date and time"
          name="pickupDateTime"
          value={formData.pickupDateTime}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Form.Group controlId="dropOffDateTime">
        <Form.Label>Drop-off Date and Time</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter drop-off date and time"
          name="dropOffDateTime"
          value={formData.dropOffDateTime}
          onChange={handleInputChange}
        />
      </Form.Group>
      <Button variant="primary" type="submit">
        Submit
      </Button>
    </Form>
  );
};

export default ReservationForm;
