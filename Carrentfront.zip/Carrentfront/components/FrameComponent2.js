import { useMemo } from "react";
import "./FrameComponent2.css";
import PropTypes from "prop-types";


const FrameComponent2 = ({
  className = "",
  iocnContainer,
  manyPickupLocation,
  weHaveAnExtensiveNumberOf,
  propWidth,
  propAlignSelf,
}) => {
  const frameDivStyle = useMemo(() => {
    return {
      width: propWidth,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propAlignSelf]);

  return (
    <div className={`frame-parent31 ${className}`} style={frameDivStyle}>
      <div className="frame-parent32">
        <div className="iocn-container-wrapper">
          <img className="iocn-container-icon" alt="" src={iocnContainer} />
        </div>
        <h3 className="many-pickup-location">{manyPickupLocation}</h3>
      </div>
      <div className="we-have-an-extensive-number-of-wrapper">
        <div className="we-have-an">{weHaveAnExtensiveNumberOf}</div>
      </div>
    </div>
  );
};

FrameComponent2.propTypes = {
  className: PropTypes.string,
  iocnContainer: PropTypes.string,
  manyPickupLocation: PropTypes.string,
  weHaveAnExtensiveNumberOf: PropTypes.string,

  /** Style props */
  propWidth: PropTypes.any,
  propAlignSelf: PropTypes.any,
};

export default FrameComponent2;
