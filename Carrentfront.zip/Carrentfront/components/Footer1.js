import "./Footer1.css";
import PropTypes from "prop-types";


const Footer = ({ className = "" }) => {
  return (
    <div className={`footer1 ${className}`}></div>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
