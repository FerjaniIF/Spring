import FrameComponent4 from "./FrameComponent4";
import FrameComponent3 from "./FrameComponent3";
import FrameComponent1 from "./FrameComponent1";
import FrameComponent from "./FrameComponent";
import Footer from "./Footer";
import PropTypes from "prop-types";
import "./HomePage.css";

const HomePage = ({ className = "" }) => {
  return (
    <div className={`home-page ${className}`}>
      <img
        className="unsplashfmbwfdivrps-icon"
        alt=""
        src="/unsplashfmbwfdivrps@2x.png"
      />
      <FrameComponent4 />
      <section className="home-page-inner">
        <div className="frame-group">
          <FrameComponent3 />
          <FrameComponent1 />
          <div className="pricing-wrapper">
            <h1 className="pricing">Pricing</h1>
          </div>
          <FrameComponent />
        </div>
      </section>
      <Footer />
    </div>
  );
};

HomePage.propTypes = {
  className: PropTypes.string,
};

export default HomePage;
