import "./InputFields.css";
import PropTypes from "prop-types";

const InputFields = ({ className = "" }) => {
  return (
    <div className={`input-fields ${className}`}>
      <div className="name-fields">
        <div className="first-name-field">
          <div className="first-name1">
            <b className="first-name2">First Name</b>
            <div className="last-name-field">
              <b className="last-name1">Last Name</b>
              <div className="contact-fields">
                <b className="email3">Email</b>
                <b className="ph-no">Ph no.</b>
              </div>
            </div>
            <div className="personal-info">
              <b className="dob">ID N°</b>
              <b className="id-no">Licence N°</b>
            </div>
          </div>
        </div>
        <div className="autofill-toggle-parent">
          <div className="autofill-toggle">
            <div className="autofill-toggle-child" />
          </div>
          <div className="different-email-toggle" />
          <div className="autofill-options">
            <div className="autofill-options-content">
              <div className="autofill-options-content-child" />
              <input
                className="autofill-or-different"
                placeholder="Autofill or Different Email"
                type="text"
              />
            </div>
            <div className="autofill-options-content1">
              <div className="autofill-options-content-item" />
              <div className="different-email-option-wrapper">
                <b className="different-email-option">+216</b>
              </div>
              <div className="arrows-upper-arrow-container">
                <img
                  className="arrows-upper-arrow1"
                  alt=""
                  src="/arrows--upper-arrow1.svg"
                />
              </div>
              <img
                className="autofill-options-content-inner"
                alt=""
                src="/line-1.svg"
              />
            </div>
          </div>
          <div className="date-field">
            <div className="date-input" />
            <input className="mdy" placeholder="M/D/Y" type="text" />
          </div>
          <img
            className="frame-child33"
            loading="lazy"
            alt=""
            src="/rectangle-12.svg"
          />
        </div>
      </div>
      <div className="pickup-location-wrapper">
        <div className="pickup-location">
          <div className="location-picker">
            <div className="location-picker-child" />
            <img
              className="solidnavigationmap-location-icon4"
              alt=""
              src="/solidnavigationmaplocation.svg"
            />
            <div className="pickup-label">
              <b className="pick-up-location">Pick up location</b>
            </div>
          </div>
          <div className="date-time-pickers">
            <div className="date-time-pickers-content">
              <div className="date-time-pickers-content-child" />
              <div className="pickup-date-time">
                <img
                  className="business-calendar4"
                  alt=""
                  src="/business--calendar.svg"
                />
              </div>
              <b className="pick-up-date-and">Pick-up Date and Time</b>
              <div className="arrows-upper-arrow-frame">
                <img
                  className="arrows-upper-arrow2"
                  alt=""
                  src="/arrows--upper-arrow-1.svg"
                />
              </div>
            </div>
            <div className="date-time-pickers-content1">
              <div className="date-time-pickers-content-item" />
              <div className="frame-parent43">
                <div className="business-calendar-wrapper">
                  <img
                    className="business-calendar5"
                    alt=""
                    src="/business--calendar.svg"
                  />
                </div>
                <b className="drop-off-date-and">Drop-off Date and TIme</b>
              </div>
              <div className="arrows-upper-arrow-wrapper1">
                <img
                  className="arrows-upper-arrow3"
                  alt=""
                  src="/arrows--upper-arrow-1.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

InputFields.propTypes = {
  className: PropTypes.string,
};

export default InputFields;
