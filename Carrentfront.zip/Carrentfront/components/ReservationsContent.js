import "./ReservationsContent.css";
import PropTypes from "prop-types";

const ReservationsContent = ({ className = "" }) => {
  return (
    <section className={`reservations-content ${className}`}>
      <div className="car-details2">
        <h1 className="mycarnow2">MyCarNow</h1>
      </div>
      <div className="car-info2">
        <div className="car-attributes">
          <div className="attributes-row">
            <div className="brand-model">
              <div className="brand-model-values">
                <div className="brand-model-values-child" />
                <div className="model1">{`Model `}</div>
                <img className="brand-icon" alt="" src="/brand-input@2x.png" />
              </div>
              <div className="brand-model-values1">
                <div className="brand-model-values-item" />
                <div className="brand3">Brand</div>
                <img className="icon30" alt="" src="/1353309200-3@2x.png" />
              </div>
            </div>
            <button className="reservation-details1">
              <img
                className="reservation-details-child"
                alt=""
                src="/rectangle-10.svg"
              />
              <div className="my-reservations2">My Reservations</div>
            </button>
          </div>
        </div>
        <div className="car-visuals">
          <div className="visuals-container">
            <div className="shapes">
              <img className="shapes-child" loading="lazy" alt="" />
            </div>
            <img className="visuals-container-child" loading="lazy" alt="" />
          </div>
          <div className="car-display">
            <div className="car-image-container">
              <div className="rectangle-parent3">
                <div className="frame-child34" />
                <div className="car-image-data">
                  <div className="car-image-details">
                    <div className="image-and-details">
                      <h3 className="honda-civic3">Honda Civic</h3>
                      <div className="pngegg-2-1-parent">
                        <img
                          className="pngegg-2-11"
                          alt=""
                          src="/pngegg-2-1@2x.png"
                        />
                        <img
                          className="frame-child35"
                          loading="lazy"
                          alt=""
                          src="/group-4091.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="booking-info1">
                    <div className="rental-period">
                      <div className="dt-day-container">
                        <b>{`20 DT `}</b>
                        <span className="day3">/ day</span>
                      </div>
                    </div>
                    <img
                      className="booking-info-child"
                      loading="lazy"
                      alt=""
                      src="/line-6.svg"
                    />
                    <div className="car-icon">
                      <div className="icon-container">
                        <button className="transport-car-container">
                          <img
                            className="transport-car4"
                            alt=""
                            src="/transport--car3.svg"
                          />
                        </button>
                        <img
                          className="frame-icon"
                          loading="lazy"
                          alt=""
                          src="/frame1.svg"
                        />
                        <div className="gas-station-icon">
                          <img
                            className="icround-local-gas-station-icon1"
                            loading="lazy"
                            alt=""
                            src="/icroundlocalgasstation1.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="car-type">
                  <div className="type-and-fuel">
                    <b className="economy3">Economy</b>
                    <div className="auto-label">
                      <b className="auto3">Auto</b>
                    </div>
                    <b className="petrol3">Petrol</b>
                  </div>
                </div>
                <div className="details-button">
                  <button className="rectangle-parent4">
                    <div className="frame-child36" />
                    <b className="view-details">View Details</b>
                  </button>
                </div>
              </div>
              <div className="separator-wrapper">
                <div className="separator" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

ReservationsContent.propTypes = {
  className: PropTypes.string,
};

export default ReservationsContent;
