import FrameComponent1 from "./FrameComponent1";
import FrameComponent from "./FrameComponent";
import PropTypes from "prop-types";
import "./AdminLogin.css";

const AdminLogin = ({ className = "" }) => {
  return (
    <div className={`adminlogin ${className}`}>
      <div className="background" />
      <FrameComponent1 />
      <div className="frame-parent">
        <div className="email-wrapper">
          <b className="email">Email</b>
        </div>
        <div className="frame-child" />
      </div>
      <FrameComponent />
      <div className="signinbutton-wrapper">
        <button className="signinbutton">
          <div className="signinbutton-child" />
          <b className="continue">Continue</b>
        </button>
      </div>
    </div>
  );
};

AdminLogin.propTypes = {
  className: PropTypes.string,
};

export default AdminLogin;
