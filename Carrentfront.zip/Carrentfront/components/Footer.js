import "./Footer.css";
import PropTypes from 'prop-types';
  

const Footer = ({ className = "" }) => {
  return (
    <section className={`footer ${className}`}>
      <img className="wave-2-icon" alt="" src="/wave-2.svg" />
      <div className="section">
        <div className="section-child" />
        <div className="communication-phone-parent">
          <img
            className="communication-phone"
            loading="lazy"
            alt=""
            src="/communication--phone.svg"
          />
          <div className="wrapper">
            <div className="div">+11111111111</div>
          </div>
        </div>
        <div className="section-inner">
          <div className="frame-parent42">
            <div className="communication-mail-wrapper">
              <img
                className="communication-mail"
                loading="lazy"
                alt=""
                src="/communication--mail.svg"
              />
            </div>
            <div className="mycarnowmailcom">MyCarNow@mail.com</div>
          </div>
        </div>
      </div>
    </section>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
